$('.logo-slider').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    // dots: true, 
    // arrows: true,
    autoplay: true,
    autoplaySpeed: 800,
    infinite: true
});

$('.logo-slider2').slick({
    slidesToShow: 2,
    slidesToScroll: 2,
    // dots: true, 
    // arrows: true,
    autoplay: true,
    autoplaySpeed: 800,
    infinite: true
});